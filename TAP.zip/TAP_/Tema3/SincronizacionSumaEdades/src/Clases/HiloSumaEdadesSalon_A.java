
package Clases;

import java.util.logging.Level;
import java.util.logging.Logger;

public class HiloSumaEdadesSalon_A extends Thread{
    
    private int Compr=0,Vr=0;
    
    public HiloSumaEdadesSalon_A(int v){
        Vr=v;
    }
    public void run(){
        sumar(Vr);
    }
    
    private synchronized void sumar(int x){
        try{
            Compr=Compr+x;
            System.out.println("Hilo=> "+Thread.currentThread().getName()+" actualiza el valor de la variable: "+Compr);
            Thread.sleep(1000);
            System.out.println("- - - - - - - - - - - - - - - - - -");
        }catch(InterruptedException y){
            Logger.getLogger(HiloSumaEdadesSalon_A.class.getName()).log(Level.SEVERE,null,y);
        }
    }
}
