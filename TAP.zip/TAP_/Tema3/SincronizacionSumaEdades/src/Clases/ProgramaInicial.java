
package Clases;

import Clases.HiloSumaEdadesSalon_A;

public class ProgramaInicial {
    public static void main(String[] args) {
        
        HiloSumaEdadesSalon_A x=new HiloSumaEdadesSalon_A(10);
        Thread Ha=new Thread(x);
        Thread Hb=new Thread(x);
        Thread Hc=new Thread(x);
        Ha.start();
        Hb.start();
        Hc.start();
    }
}
