
package Clases;

import Clases.HiloNumeroPositivoNegativo_Runnable;

public class Principal_Runnable {
    
    public static void main(String[] args) {
        Runnable x=new HiloNumeroPositivoNegativo_Runnable(2);
        Runnable y=new HiloNumeroPositivoNegativo_Runnable(-33);
        Runnable z=new HiloNumeroPositivoNegativo_Runnable(-12);
        Runnable w=new HiloNumeroPositivoNegativo_Runnable(82);
    }
}
