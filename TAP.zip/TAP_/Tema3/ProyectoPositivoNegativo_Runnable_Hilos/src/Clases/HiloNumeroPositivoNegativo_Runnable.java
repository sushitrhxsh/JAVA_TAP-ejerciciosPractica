
package Clases;


public class HiloNumeroPositivoNegativo_Runnable implements Runnable{

    private int dn;
    Thread H;
    
    public  HiloNumeroPositivoNegativo_Runnable(int n){
        dn=n;
        H =new Thread(this);
        H.start();
    }
    
    public void run() {
        if(dn>=0)
            System.out.print("El numero "+dn+" es positivo\n");
        else
            System.out.print("El numero "+dn+" es negativo\n");
    }
  
}
