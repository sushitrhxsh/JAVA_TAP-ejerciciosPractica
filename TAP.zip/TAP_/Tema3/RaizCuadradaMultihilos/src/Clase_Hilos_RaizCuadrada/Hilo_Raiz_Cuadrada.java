
package Clase_Hilos_RaizCuadrada;

import static java.lang.Math.sqrt;


public class Hilo_Raiz_Cuadrada extends Thread {
    
    double nr;
    
    public  Hilo_Raiz_Cuadrada (double a){
    nr=a;
    }
    
    public void run(){
        System.out.println("La raiz cuadrada del numero: "+ nr + " es "+ sqrt(nr));
    }
}
