
package Clase_Hilos_RaizCuadrada;


public class Principal {
    
    public static void main(String[] args){
        Hilo_Raiz_Cuadrada x=new Hilo_Raiz_Cuadrada(10);
        Hilo_Raiz_Cuadrada y=new Hilo_Raiz_Cuadrada(8);
        Hilo_Raiz_Cuadrada z=new Hilo_Raiz_Cuadrada(6);
        Hilo_Raiz_Cuadrada w=new Hilo_Raiz_Cuadrada(4);
        Hilo_Raiz_Cuadrada v=new Hilo_Raiz_Cuadrada(2);
        
        x.start();
        y.start();
        z.start();
        w.start();
        v.start();
        
    }
}
