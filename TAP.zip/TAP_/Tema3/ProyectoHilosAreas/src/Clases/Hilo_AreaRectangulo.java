/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;


public class Hilo_AreaRectangulo extends Thread{
    
    private double Br;
    private double Hr;
 
    public Hilo_AreaRectangulo(double b,double h){
        Br = b;
        Hr = h;
    }
    
    public void run(){
        System.out.println("El area del rectangulo es: "+ Br*Hr);
    }
}
