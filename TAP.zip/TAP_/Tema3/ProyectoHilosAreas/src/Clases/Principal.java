
package Clases;


public class Principal {
    
    public static void main(String[] args) {
        
        Hilo_AreaRectangulo x1=new Hilo_AreaRectangulo(3,5);
        Hilo_AreaRectangulo y1=new Hilo_AreaRectangulo(2,5);
       
        Hilo_AreaTraingulo x2=new Hilo_AreaTraingulo(5,8);
        Hilo_AreaTraingulo y2=new Hilo_AreaTraingulo(2,4);
        
        x1.start();
        y1.start();
        x2.start();
        y2.start();
    }
}
