
package Clases;


public class Hilo_AreaTraingulo extends Thread{
    
    private double Bt;
    private double Ht;
    
    public Hilo_AreaTraingulo(double b,double h){
        Bt = b;
        Ht = h;
    }
    
    public void run(){
        System.out.println("El area del traingulo es: "+(Bt*Ht)/2);
    }
}
