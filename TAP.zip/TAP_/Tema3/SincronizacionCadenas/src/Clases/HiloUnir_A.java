
package Clases;

import java.util.logging.Level;
import java.util.logging.Logger;

public class HiloUnir_A extends Thread{
    
    private String Pal;
    private int Pos;
    String[] Lispal={"Alex","Fernandez","Sanchez"};
    
    public HiloUnir_A(String x){
        Pal=x;
    }
    
    public void run(){
        Unir(Pal);
    }
    
    private synchronized void Unir(String x){
        try{
            Pal=Pal+Lispal[Pos];
            Pos=Pos+1;
            System.out.println("Hilo=> "+Thread.currentThread().getName()+" actualiza el valor de la variable: "+Pal);
            Thread.sleep(1000);
            System.out.println("- - - - - - - - - - - - - - - - - -");
        }catch(InterruptedException y){
            Logger.getLogger(HiloUnir_A.class.getName()).log(Level.SEVERE,null,y);
        }
    }
}
