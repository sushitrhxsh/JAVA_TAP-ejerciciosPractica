
package Clases;

import Clases.HiloUnir_A;

public class ProgramaInicial {
    public static void main(String[] args) {
        
        HiloUnir_A x=new HiloUnir_A("Unir Palabras: ");
        Thread Ha=new Thread(x);
        Thread Hb=new Thread(x);
        Thread Hc=new Thread(x);
        Ha.start();
        Hb.start();
        Hc.start();
    }    
}

