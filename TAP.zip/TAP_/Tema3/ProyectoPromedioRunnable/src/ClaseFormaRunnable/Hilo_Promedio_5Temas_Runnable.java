
package ClaseFormaRunnable;


public class Hilo_Promedio_5Temas_Runnable implements Runnable{
    
    private double Ct1,Ct2,Ct3,Ct4,Ct5;  
    private String Nom_es;
    private String Nmt;
    Thread Hilo_y;

    public Hilo_Promedio_5Temas_Runnable(double c1,double c2,double c3,double c4,double c5,String nom,String mat){
        Ct1=c1;
        Ct2=c2;
        Ct3=c3;
        Ct4=c4;
        Nom_es=nom;
        Nmt=mat;
        Hilo_y=new Thread(this);
        Hilo_y.start();
    }
    
   public void run() {
      double P5=(Ct1+Ct2+Ct3+Ct4+Ct5)/5;
     System.out.println("El estudiante: "+Nom_es+" tienes un promedio de 5 calificiones de: "+P5+" de la materia: "+Nmt);
   }
}
