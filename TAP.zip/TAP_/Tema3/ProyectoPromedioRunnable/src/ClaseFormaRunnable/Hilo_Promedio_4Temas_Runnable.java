
package ClaseFormaRunnable;


public class Hilo_Promedio_4Temas_Runnable implements Runnable{
    private double Ct1;
    private double Ct2;
    private double Ct3;
    private double Ct4;
    private String Nom_es;
    private String Nmt;
    Thread Hilo_x;

    public Hilo_Promedio_4Temas_Runnable(double c1,double c2,double c3,double c4,String nom,String mat){
        Ct1=c1;
        Ct2=c2;
        Ct3=c3;
        Ct4=c4;
        Nom_es=nom;
        Nmt=mat;
        Hilo_x=new Thread(this);
        Hilo_x.start();
    }
    
   public void run() {
     double P4=(Ct1+Ct2+Ct3+Ct4)/4;
     System.out.println("El estudiante: "+Nom_es+" tienes un promedio de 4 calificiones de: "+P4+" de la materia: "+Nmt);
   }
 }
