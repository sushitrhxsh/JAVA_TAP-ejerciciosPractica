
package ClaseFormaRunnable;


public class PrincipalPromedio_Runnable {
    
    public static void main(String[] args) {
        Runnable x1=new Hilo_Promedio_5Temas_Runnable(100,70,60,90,98,"Luis","Quimica");
        Runnable x2=new Hilo_Promedio_5Temas_Runnable(90,90,80,70,100,"Ariel","Quimica"); 
        Runnable x3=new Hilo_Promedio_5Temas_Runnable(80,80,90,100,100,"karla","Quimica");
        
        Runnable y1=new Hilo_Promedio_4Temas_Runnable(70,80,88,91,"Luis","Matematicas");
        Runnable y2=new Hilo_Promedio_4Temas_Runnable(80,100,70,99,"Ariel","Matematicas");
        Runnable y3=new Hilo_Promedio_4Temas_Runnable(90,50,98,100,"Karla","Matematicas");
    }
}
