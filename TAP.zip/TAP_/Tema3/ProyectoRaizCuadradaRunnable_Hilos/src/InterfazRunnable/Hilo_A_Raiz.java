
package InterfazRunnable;


public class Hilo_A_Raiz implements Runnable{
    
    private double n;
    Thread hilo_x;

    public Hilo_A_Raiz(double y) {
        n=y;
        hilo_x = new Thread (this);
        hilo_x.start();
        
    }
    
    public void run(){
        System.out.print("La raiz del numero: "+n+" es: "+n*n+ "..  Nombre del hilo: "+hilo_x+"\n");
    }
    
}
