
package InterfazRunnable;

import InterfazRunnable.Hilo_A_Raiz;

public class Principal_Runnable {
    
    public static void main(String[] args) {
        Runnable x=new Hilo_A_Raiz(10);
        Runnable y=new Hilo_A_Raiz(14);
        Runnable z=new Hilo_A_Raiz(12);
    }
}
