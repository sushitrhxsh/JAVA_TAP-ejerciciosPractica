
package ClasesFormaThread;


public class Hilo_Promedio_4Temas_Thread extends Thread{
    
    private double Ct1;
    private double Ct2;
    private double Ct3;
    private double Ct4;
    private String Nom_Es;

    public Hilo_Promedio_4Temas_Thread(double c1,double c2,double c3,double c4,String nom) {
        Ct1=c1;
        Ct2=c2;
        Ct3=c3;
        Ct4=c4;
        Nom_Es=nom;
    }
    
    public void run(){
        double P4;
        P4=(Ct1+Ct2+Ct3+Ct4)/4;
        System.out.println("El estudiante: "+Nom_Es+ " y su promedio de 4 temas es: "+P4);
    }
}
