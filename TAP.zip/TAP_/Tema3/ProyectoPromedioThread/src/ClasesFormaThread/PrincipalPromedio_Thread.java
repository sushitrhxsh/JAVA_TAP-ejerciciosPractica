
package ClasesFormaThread;

import ClasesFormaThread.Hilo_Promedio_4Temas_Thread;
import ClasesFormaThread.Hilo_Promedio_5Temas_Thread;

public class PrincipalPromedio_Thread {
    
    public static void main(String[] args) {
        
        Hilo_Promedio_4Temas_Thread x=new Hilo_Promedio_4Temas_Thread(100,90,100,70,"Luis");
        Hilo_Promedio_4Temas_Thread y=new Hilo_Promedio_4Temas_Thread(88,70,90,100,"Ariel");
        Hilo_Promedio_4Temas_Thread z=new Hilo_Promedio_4Temas_Thread(90,65,88,100,"Karla");
        
        Hilo_Promedio_5Temas_Thread u=new Hilo_Promedio_5Temas_Thread(100,80,79,90,89,"Luis");
        Hilo_Promedio_5Temas_Thread v=new Hilo_Promedio_5Temas_Thread(75,81,69,100,76,"Arie;");
        Hilo_Promedio_5Temas_Thread w=new Hilo_Promedio_5Temas_Thread(100,95,96,93,99,"Karla");
        
        x.start();
        y.start();
        z.start();
        u.start();
        v.start();
        w.start();
    }
}
