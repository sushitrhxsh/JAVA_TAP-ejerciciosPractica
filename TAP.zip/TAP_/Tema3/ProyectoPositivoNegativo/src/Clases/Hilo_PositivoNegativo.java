
package Clases;


public class Hilo_PositivoNegativo extends Thread{
    
    private int dt;
    
    public Hilo_PositivoNegativo(int a){
        dt=a;
    }
    
    public void run(){
        if(dt>=0)
            System.out.print("El numero "+dt+" es positivo\n");
        else
            System.out.print("El numero "+dt+" es negativo\n");
    }
}
