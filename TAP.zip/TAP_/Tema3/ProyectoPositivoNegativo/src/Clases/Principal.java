
package Clases;


public class Principal {
    
    public static void main(String[] args) {
        
        Hilo_PositivoNegativo a=new Hilo_PositivoNegativo(2);
        Hilo_PositivoNegativo b=new Hilo_PositivoNegativo(-3);
        Hilo_PositivoNegativo c=new Hilo_PositivoNegativo(0);
        Hilo_PositivoNegativo d=new Hilo_PositivoNegativo(10);
        Hilo_PositivoNegativo e=new Hilo_PositivoNegativo(-27);
        Hilo_PositivoNegativo f=new Hilo_PositivoNegativo(9);
        a.start();
        b.start();
        c.start();
        d.start();
        e.start();
        f.start();
    }
}
