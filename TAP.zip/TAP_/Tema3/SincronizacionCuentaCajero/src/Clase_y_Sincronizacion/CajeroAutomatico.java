
package Clase_y_Sincronizacion;

import java.util.logging.Level;
import java.util.logging.Logger;

public class CajeroAutomatico extends Thread{
    
    CuentaBancaria MicuentaB=new CuentaBancaria();
    
    public void run() {
        for (int i=0;i<5;i++){ 
            try{
                retirardinerocuenta(10); 
                if (MicuentaB.getsaldoactual()<=0){
                    System.out.println("Su cuenta posee saldo negativo !!!");
                }
                Thread.sleep(500);
            }catch(InterruptedException e){
               Logger.getLogger(CajeroAutomatico.class.getName()).log(Level.SEVERE,null,e); 
           } } }
    
    private synchronized void retirardinerocuenta(int vr) {
      if (MicuentaB.getsaldoactual()>= vr) {
          System.out.println("Saldo Actual="+MicuentaB.getsaldoactual());
          System.out.println("El usuario: "+ Thread.currentThread().getName()+" Esta realizando un retiro de : "+vr+ " pesos");
          MicuentaB.retirocuenta(vr);
          System.out.println("El retiro se realizo exitosamente !!!, el nuevo saldo es: "+MicuentaB.getsaldoactual());
          System.out.println("---------------------------------------------------");
      }else{
         System.out.println("Senor "+Thread.currentThread().getName()+" No hay saldo suficiente para realizar la transaccion");
         System.out.println("---------------------------------------------------");
      } } 
}