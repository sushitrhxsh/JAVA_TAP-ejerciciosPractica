
package Clase_y_Sincronizacion;


public class PrincipioPrograma {
    public static void main(String[] args) {
        CajeroAutomatico x= new CajeroAutomatico ();

    Thread Ha = new Thread(x, "Cliente Pedro");
    Thread Hb = new Thread(x, "Cliente Pablo");
    Thread Hc = new Thread(x, "Cliente Ximena");

    Ha.start();
    Hb.start();
    Hc.start();
    }
}
