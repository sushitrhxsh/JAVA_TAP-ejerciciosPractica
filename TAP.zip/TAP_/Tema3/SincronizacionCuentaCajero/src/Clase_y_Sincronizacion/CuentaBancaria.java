
package Clase_y_Sincronizacion;


public class CuentaBancaria extends Thread{
    
    private int saldoactual=50;
    private int importe=0;
    
    public synchronized int getsaldoactual(){
        return saldoactual;
    }
    public synchronized void retirocuenta(int vr){
        saldoactual= saldoactual-vr;
    }
}