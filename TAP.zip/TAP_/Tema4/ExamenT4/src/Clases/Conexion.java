
package Clases;

import java.sql.*; 
import javax.swing.JOptionPane;

public class Conexion {
    Connection conectar =null; 
     public Connection conectar() 
       { 
           try 
           { 
             conectar = DriverManager.getConnection("jdbc:ucanaccess://C:\\T4_TAP_AlexFernandez\\BDCentroInformacion.accdb"); 
           } catch (Exception e) 
                   {
                JOptionPane.showMessageDialog(null,"Error al conectar.."+e); 
                   } 
           return conectar; 
      } 
}

