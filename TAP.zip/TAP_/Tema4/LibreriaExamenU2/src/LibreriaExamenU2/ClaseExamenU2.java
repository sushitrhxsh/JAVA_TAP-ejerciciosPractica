
package LibreriaExamenU2;

public class ClaseExamenU2 {
    
    public double CorteCabello(double a,double b){
        double R;
        return R=a*b;
    }
    public int NumMenor(int a,int b,int c,int d){
        int m=0;
        if(a<b && a<c && a<d)
            m=a;
        else if(b<a && b<c && b<d)
            m=b;
        else if(c<a && c<b && c<d)
            m=c;
        else if (d<a && d<b && d<c)
            m=d;
        else
            m=0;
      return m;
    }
    public double BoletoDesc(double a,double b,double c){
        double P,R,A,D;
        P=a*b;
        D=c/100;
        R=P*D;
        A=P-R;
        return A;
    }
}