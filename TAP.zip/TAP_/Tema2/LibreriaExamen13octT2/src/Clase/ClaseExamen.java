
package Clase;


public class ClaseExamen {
     public String NumParImp(int a){
        String r,l;
        if(a%2==0)
              return r= "es par";
        else 
             return l= "es impar";
    }
    public String NumPosioNeg(double a){
        String r,t;
        if(a>=0)
            return r="Es positivo";
        else 
          return t="Es negativo";
    }
    public double RaizCuadra(double a){
        return a*a;
    }
    public String NumMes(int a){
        String [] numeros = new String[] {"Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"};
        return numeros [a-1]; 
    }
}
