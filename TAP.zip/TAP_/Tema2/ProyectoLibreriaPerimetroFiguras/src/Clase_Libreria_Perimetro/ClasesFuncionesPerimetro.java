
package Clase_Libreria_Perimetro;


public class ClasesFuncionesPerimetro {
    
    public double perimetro_traingulo(double a,double b, double c){
        double RPT;
        RPT=a+b+c;
        return RPT;
    }
    public double perimetro_cuadrado(double a){
        double RPC;
        RPC=4*a;
        return RPC;
    }  
    public double perimetro_rectangulo(double a,double b){
        double RPR;
        RPR=(2*a)+(2*b);
        return RPR;
    }
    public double perimetro_rombo(double a){
        double RPR;
        RPR=4*a;
        return RPR;
    }
    public double perimetro_romboide(double a,double b){
        double RPR;
        RPR=(2*a)+(2*b);
        return RPR;
    }
    public double perimetro_trapecio(double a,double b, double c,double d){
        double RPT;
        RPT=a+b+c+d;
        return RPT;
    }
}
