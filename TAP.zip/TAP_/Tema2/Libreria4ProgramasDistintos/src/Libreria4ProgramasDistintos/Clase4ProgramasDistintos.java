
package Libreria4ProgramasDistintos;


public class Clase4ProgramasDistintos {
    public double convertir_CM_a_IN (double a){

        return  a*0.393701;
    }
    
    public double PerimetroTrapecio(double a, double b, double c, double d){
        
        return a+b+c+d;
    }
    
    public String NumeroRomano(int a){
        String [] numeros = new String[] {"I","II","III","IV","V","VI","VII","VIII","IX","X"};
        return numeros [a-1]; 
    }
    
    public double NumMenor2Numeros(double a, double b){
    
        return a<b ? a:b;
    }
}
