
package LibreriaCalculadora2Numeros;

public class ClaseCalculadora2Num {
    public int suma2num(int a,int b){
        int R;
        R=a+b;
        return R;
    }
    public int resta2num(int a,int b){
        int R;
        R=a-b;
        return R;
    }
    public int multi2num(int a,int b){
        int R;
        R=a*b;
        return R;
    }
    public int div2num(int a,int b){
        int R;
        R=a/b;
        return R;
    }
    public int raiz2num(int a){
        int R;
        R=a*a;
        return R;
    }
}
