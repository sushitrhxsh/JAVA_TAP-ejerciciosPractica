
package libreriasmayormenor;

public class Mayor_Menor {    
    public int NumeroMayor(int a, int b, int c, int d){
    int M=0;
        if(a>b && a>c && a>d)
            M=a;
        else if(b>a && b>c && b>d)
            M=b;
        else if(c>a && c>b && c>d)
            M=c;
        else if (d>a && d>b && d>c)
            M=d;
        else
            M=0;
        
    return M;
    }
    
        public int NumeroMenor(int a, int b, int c, int d){
    int m=0;
        if(a<b && a<c && a<d)
            m=a;
        else if(b<a && b<c && b<d)
            m=b;
        else if(c<a && c<b && c<d)
            m=c;
        else if (d<a && d<b && d<c)
            m=d;
        else
            m=0;
        
    return m;
    }
}
