
package LibreriaSumaCalificaciones;


public class Clase_LibreriaSumaCalificaciones {
    public double suma_3_calif(double a, double b,double c){
        double S3;
        S3=a+b+c;
        return S3;
    }
     public double suma_4_calif(double a, double b,double c,double d){
        double S4;
        S4=a+b+c+d;
        return S4;
    }
     public double suma_5_calif(double a, double b,double c,double d, double e){
        double S5;
        S5=a+b+c+d+e;
        return S5;
    }
     
     public int suma_3_calif(int a, int b,int c){
        int S3;
        S3=a+b+c;
        return S3;
    }
     public int suma_4_calif(int a, int b,int c,int d){
        int S4;
        S4=a+b+c+d;
        return S4;
    }
     public int suma_5_calif(int a, int b,int c,int d, int e){
        int S5;
        S5=a+b+c+d+e;
        return S5;
    }

}
