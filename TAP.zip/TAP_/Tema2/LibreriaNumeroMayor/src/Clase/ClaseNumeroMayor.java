
package Clase;

public class ClaseNumeroMayor {
    public int numeromayor3(int a, int b, int c){
    int m=0;
    if(a>b && a>c)
        m=a;
    else if(b>a && b>c)
        m=b;
    else if(c>a && c>b)
        m=c;
    return m;
    }
    
    public int numeromayor4(int a, int b, int c, int d){
    int m=0;
    if(a>b && a>c && a>d)
        m=a;
    else if(b>a && b>c && b>d)
        m=b;
    else if(c>a && c>b && b>d)
        m=c;
    else if (d>a && d>b && d>c)
        m=d;
    return m;
    }
}
    