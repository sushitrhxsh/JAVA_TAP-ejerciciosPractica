
package ClaseLibreriaConversiones;


public class ClaseFuncionesConversiones {
    
    public double conversion_GaL(double a){
        double RG;
        RG= a*3.785;
        return RG;
    }
    public double conversion_LaG(double a){
        double RL;
        RL= a/3.785;
        return RL;
    }
}
