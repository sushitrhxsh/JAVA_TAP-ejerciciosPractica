
package LibreriaClaseVariasConversiones;


public class ClaseVariasConversiones {
    public double ConverPesos_Dolar(double a,double b){
        double CO;
        CO = a/b;
        return CO;
    }
    public double ConverDolar_Pesos(double a,double b){
        double CO;
        CO = a*b;
        return CO;
    }
    public double ConverDolar_Libras(double a,double b){
        double CO;
        CO = a*b;
        return CO;
    }
    public double ConverDolar_Euros(double a,double b){
        double CO;
        CO = a*b;
        return CO;
    }
}
